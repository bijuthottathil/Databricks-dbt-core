-- models/customer_summary.sql
SELECT 
  city, 
  COUNT(*) AS total_customers
FROM {{ ref('customers') }}
GROUP BY city
